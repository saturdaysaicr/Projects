
const horasData = ['00:00:00 - 02:59:59',
                '03:00:00 - 05:59:59',
                '06:00:00 - 08:59:59',
                '09:00:00 - 11:59:59',
                '12:00:00 - 14:59:59',
                '15:00:00 - 17:59:59',
                '18:00:00 - 20:59:59',
                '21:00:00 - 23:59:59']


jQuery(document).ready(function () {
    setRandomColor();
    const TOTAL = 7849;
    const NACIONALIDAD = "Costa Rica";
    const AUTO = 1;
    const PROVINCIA = "SAN JOSE"

    /**
     * detect IE
     * returns version of IE or false, if browser is not Internet Explorer
     */
    function detectIE() {
        var ua = window.navigator.userAgent;

        var msie = ua.indexOf("MSIE ");
        if (msie > 0) {
            // IE 10 or older => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)), 10);
        }

        var trident = ua.indexOf("Trident/");
        if (trident > 0) {
            // IE 11 => return version number
            var rv = ua.indexOf("rv:");
            return parseInt(ua.substring(rv + 3, ua.indexOf(".", rv)), 10);
        }

        // var edge = ua.indexOf('Edge/');
        // if (edge > 0) {
        //     // Edge (IE 12+) => return version number
        //     return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        // }

        // other browser
        return false;
    }

    function setVideoHeight() {
        const videoRatio = 1920 / 1080;
        const minVideoWidth = 400 * videoRatio;
        let secWidth = 0,
            secHeight = 0;

        secWidth = videoSec.width();
        secHeight = videoSec.height();

        secHeight = secWidth / 2.13;

        if (secHeight > 600) {
            secHeight = 600;
        } else if (secHeight < 400) {
            secHeight = 400;
        }

        if (secWidth > minVideoWidth) {
            $("video").width(secWidth);
        } else {
            $("video").width(minVideoWidth);
        }

        videoSec.height(secHeight);
    }

    // Parallax function
    // https://codepen.io/roborich/pen/wpAsm
    var background_image_parallax = function ($object, multiplier) {
        multiplier = typeof multiplier !== "undefined" ? multiplier : 0.5;
        multiplier = 1 - multiplier;
        var $doc = $(document);
        $object.css({
            "background-attatchment": "fixed"
        });
        $(window).scroll(function () {
            var from_top = $doc.scrollTop(),
                bg_css = "center " + multiplier * from_top + "px";
            $object.css({
                "background-position": bg_css
            });
        });
    };

    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            $(".scrolltop:hidden")
                .stop(true, true)
                .fadeIn();
        } else {
            $(".scrolltop")
                .stop(true, true)
                .fadeOut();
        }

        // Make sticky header
        if ($(this).scrollTop() > 158) {
            $(".tm-nav-section").addClass("sticky");
        } else {
            $(".tm-nav-section").removeClass("sticky");
        }
    });

    let videoSec;

    if (detectIE()) {
        alert(
            "Please use the latest version of Edge, Chrome, or Firefox for best browsing experience."
        );
    }

    videoSec = $("#tmVideoSection");

    // Adjust height of video when window is resized
    $(window).resize(function () {
        setVideoHeight();
    });

    setVideoHeight();

    $(window).on("load scroll resize", function () {
        var scrolled = $(this).scrollTop();
        var vidHeight = $("#hero-vid").height();
        var offset = vidHeight * 0.6;
        var scrollSpeed = 0.25;
        var windowWidth = window.innerWidth;

        if (windowWidth < 768) {
            scrollSpeed = 0.1;
            offset = vidHeight * 0.5;
        }

        $("#hero-vid").css(
            "transform",
            "translate3d(-50%, " + -(offset + scrolled * scrollSpeed) + "px, 0)"
        ); // parallax (25% scroll rate)
    });

    // Parallax image background
    background_image_parallax($(".tm-parallax"), 0.4);

    // Back to top
    $(".scroll").click(function () {
        console.log("top clicked")
        $("html,body").animate({
                scrollTop: $("#home").offset().top
            },
            "1000"
        );
        return false;
    });

    jQuery('#topFiveSelect').change( function(e){
        var selectedValue = $(this).find("option:selected").attr('value');
        var infoTable = ''
        var infoObject;
        /* */
        switch (selectedValue) {
            case '1': //Canton
                infoObject = topFive['byCanton'];
                break;
            case '2': //Distrito
                infoObject = topFive['byDistrito'];
                break;
            case '3':
                infoObject = topFive['byMes'];
                break;
            case '4':
                infoObject = topFive['byDia'];
                break;
            case '5':
                infoObject = topFive['byHora'];
                break;
            case '6':
                infoObject = topFive['byMarca'];
                break;
            case '7':
                infoObject = topFive['byAnho'];
                break;
            default:
                break;
        }

        for(var title in infoObject){
            infoTable+= `<tr>
            <th scope="row">${((infoObject[title]/TOTAL)*100).toFixed(2)}</th>
            <td>${title}</td>
          </tr>`
        }

        jQuery('#topFiveTable').find('tbody').empty().append(infoTable);
    });

    jQuery('#form-canton').change(function(e){
        var selectedValue = $(this).find("option:selected").text();
        console.log(selectedValue);
        var distritosOfSelected = Object.keys(districtByCanton[selectedValue]);

        var options =''
        var i=0;
        distritosOfSelected.map( d => {options+= `<option value="${i++}">${d}</option>`});

        jQuery('#form-distrito').empty().append(options);
    });

    jQuery('#form-heatmap').change(function(e){
        var selectedValue = jQuery(this).find("option:selected").attr('value');
        console.log(selectedValue)
        heatmap2.setMap(null);
        buildHeatMap2(datosPrediccionPorDistritoHora, Number(selectedValue));

    })

    jQuery('#datepicker').datepicker({
        uiLibrary: 'bootstrap4'
    });

    jQuery('#form-send').on('click', callPythonFile);
    initializeMap();
    loadCSVdata();


});

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function setRandomColor() {
    jQuery('[id*="result-unit"]').each(function (index, value) {
        jQuery("#result-unit" + (Number(index) + 1)).css("color", getRandomColor());
    });
}

jQuery('[id*="result-unit"]').on("click", function (event) {
    var unitColor = jQuery(this).css("color");
    jQuery(".prob-percent").css("color", unitColor);

    //result-unit-table
    let unitData = loadSampleUnit()
    let UnitTableRowContent = `<tr>
                                    <td>${unitData.canton}</td>
                                    <td>${unitData.distrito}</td>
                                    <td>${unitData.dia}</td>
                                    <td>${unitData.hora}</td>
                                    <td>${unitData.anho}</td>
                                    <td>${unitData.marca}</td>
                                <tr>`
    jQuery(".prob-percent").empty().append(unitData.probabilidad +'%');
    jQuery('#results-units-table').find('tbody').empty().append(UnitTableRowContent);
    jQuery("#fullHeightModalRight").modal();

});


var map;
var map2;

function initializeMap() {
    var mapProp = {
        center: new google.maps.LatLng(10, -84.2342245),
        zoom: 8,
    };
    var mapProp2 = {
        center: new google.maps.LatLng(9.5,  -84.2342245),
        zoom: 9,
        mapTypeId: google.maps.MapTypeId.HYBRID
    };
    map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    map2 = new google.maps.Map(document.getElementById("googleMap2"), mapProp2);
}

var datosActualidad;
var datosPrediccion;
var datosPrediccionPorDistritoHora;
var heatmap2; 

function loadCSVdata(){

    d3.csv("http://localhost:8080/csv/actualidad.csv").then(function(data) {
        datosActualidad=data;
        d3.csv("http://localhost:8080/csv/prediccion.csv").then(function(data) {
            datosPrediccion=data;

        let datosActualidadPorDistrito = d3.nest()
            .key(function(d) { return d.Canton; })
            .key(function(d) { return d.Distrito; })
            .rollup(function(v) { return v.length; })
            .entries(datosActualidad);

        buildHeatMap1(datosActualidadPorDistrito);

        datosPrediccionPorDistritoHora = d3.nest()
            .key(function (d) { return d.Canton; })
            .key(function (d) { return d.Distrito; })
            .key(function (d) { return d.Hora; })
            .rollup(function (v) { return d3.sum(v, function (d) { return d.Probabilidad; }); })
            .entries(datosPrediccion);

        buildHeatMap2(datosPrediccionPorDistritoHora, 1);

        });
    });
    
    

}

function buildHeatMap1(daPorDistrito){
    var heatMapData=[];
    for (const canton in districtByCanton) {
        for (const distrito in districtByCanton[canton]) {
            for (var i = 0; i < daPorDistrito.length; i++) {
                let cantonCsv = daPorDistrito[i]["key"];
                for (var j = 0; j < daPorDistrito[i]["values"].length; j++) {
                    let distritoCsv = daPorDistrito[i]["values"][j]["key"];
                    if(canton.toLowerCase() === cantonCsv.toLowerCase() && distrito.toLowerCase() === distritoCsv.toLowerCase()){
                        let lat = districtByCanton[canton][distrito]['lat'];
                        let lng = districtByCanton[canton][distrito]['lng'];
                        let weight = daPorDistrito[i]["values"][j]['value'];
                        heatMapData.push({location: new google.maps.LatLng(lat, lng), weight: weight});
                    }
                }
            }
        }
    }

    var heatmap = new google.maps.visualization.HeatmapLayer({
        data: heatMapData,
        dissipating: true,
        radius:40,
        gradient: [
            'rgba(10, 0, 198, 0)',
            'rgba(0, 103, 191, 1)',
            'rgba(0, 164, 194, 1)',
            'rgba(0, 198, 169, 1)',
            'rgba(0, 202, 112, 1)',
            'rgba(0, 206, 52, 1)',
            'rgba(9, 210, 0, 1)',
            'rgba(73, 213, 0, 1)',
            'rgba(140, 217, 0, 1)',
            'rgba(209, 221, 0, 1)',
            'rgba(225, 169, 0, 1)',
            'rgba(229, 103, 0, 1)',
            'rgba(225, 34, 0, 1)'
          ]
      });
      heatmap.setMap(map);
}

function buildHeatMap2(groupedData, pHora){
    var heatMapData=[];
    for (const canton in districtByCanton) {
        for (const distrito in districtByCanton[canton]) {
            for (var i = 0; i < groupedData.length; i++) {
                let cantonCsv = groupedData[i]["key"];
                for (var j = 0; j < groupedData[i]["values"].length; j++) {
                    let distritoCsv = groupedData[i]["values"][j]["key"];

                    if(canton.toLowerCase() === cantonCsv.toLowerCase() && distrito.toLowerCase() === distritoCsv.toLowerCase()){
                        let lat = districtByCanton[canton][distrito]['lat'];
                        let lng = districtByCanton[canton][distrito]['lng'];
                        let weight;
                        for (var k = 0; k < groupedData[i]["values"][j]['values'].length; k++) {
                            let hora = groupedData[i]["values"][j]["values"][k]['key'];
                            if(Number(hora)=== pHora){
                                weight =Math.ceil( groupedData[i]["values"][j]["values"][k]['value']);
                            }
                        }

                        heatMapData.push({location: new google.maps.LatLng(lat, lng), weight: weight});
                    }
                }
            }
        }
    }

    heatmap2 = new google.maps.visualization.HeatmapLayer({
        data: heatMapData,
        dissipating: true,
        radius:40
      });
      heatmap2.setMap(map2);
}

function loadSampleUnit(){
    
    let i = Math.floor((Math.random() * 9838) + 0);
    let unit = datosPrediccion[i];

    return{
        canton: unit['Canton'],
        distrito: unit['Distrito'],
        dia: (new Date( `${unit['FechaMonth']}/${unit['FechaDay']}/${unit['FechaYear']}`)).toDateString(),
        hora: horasData[Number(unit['Hora'])-1],
        anho: unit['AnhoVehiculo'],
        marca: unit['Marca'],
        probabilidad: Number((unit['Probabilidad'])*100).toFixed(1),
    }

}

function setFormSelects(){

}

function callPythonFile() {
    var fecha = jQuery('#datepicker').val();
    var hora = jQuery("#form-hora").find("option:selected").text();
    var canton = jQuery("#form-canton").find("option:selected").text().toUpperCase();
    var distrito = jQuery("#form-distrito").find("option:selected").text().toUpperCase();;
    var edad = jQuery("#form-edad").find("option:selected").text();
    var genero = jQuery("#form-genero").find("option:selected").attr('value');
    var marca = jQuery("#form-marca").find("option:selected").text();
    var anho =jQuery("#form-anho").find("option:selected").text();

    var horaText = jQuery("#form-hora").find("option:selected").text();

    if (fecha) {
        var xhr = new XMLHttpRequest();
        var url = `//localhost:5000/prob?f=${fecha}&h=${hora}&c=${canton}&d=${distrito}&e=${edad}&g=${genero}&m=${marca}&a=${anho}`
        xhr.onreadystatechange = function () {
            console.log(xhr.response);
            let probabilidad = (Number(xhr.response) *100).toFixed(2);

            let UnitTableRowContent = `<tr>
                                        <td>${canton}</td>
                                        <td>${distrito}</td>
                                        <td>${fecha}</td>
                                        <td>${horaText}</td>
                                        <td>${anho}</td>
                                        <td>${marca}</td>
                                    <tr>`
            jQuery(".prob-percent").empty().append(probabilidad + '%');
            jQuery('#results-units-table').find('tbody').empty().append(UnitTableRowContent);
            jQuery("#fullHeightModalRight").modal();
            
            console.log(url);

        }

        xhr.open('GET', url, true);
        xhr.send();
    } else {
        alert("Falta el campo de fecha");
    }

    
}