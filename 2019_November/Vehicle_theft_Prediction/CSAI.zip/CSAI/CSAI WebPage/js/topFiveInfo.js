const topFive = {
    byCanton: {
        'San Jose' : 2745,
        'Desamparados' : 755,
        'Montes de Oca' : 655,
        'Goicoechea' : 623,
        'Curridabat' : 440
    },
    byDistrito: {
        'San Pedro': 505,
        'Pavas' : 340,
        'Catedral' : 330,
        'Curridabat' : 301,
        'Hospital' : 292
    },
    byMarca: {
        'Toyota': 1502,
        'Hyundai': 1273,
        'Nissan' : 937,
        'Susuki': 828,
        'Honda' : 573 
    },
    byHora: {
        '18:00:00 - 20:59:59' : 1932,
        '21:00:00 - 23:59:59' : 1533,
        '00:00:00 - 02:59:59' : 1128,
        '15:00:00 - 17:59:59' : 788,
        '12:00:00 - 14:59:59' : 676
    },
    byAnho: {
        'Año 2008': 2943,
        'Año 1994': 504,
        'Año 1995': 455,
        'Año 1993': 410,
        'Año 2017': 398
    },
    byMes: {
        'Octubre' : 707,
        'Diciembre' : 687,
        'Abril' : 686,
        'Mayo' : 678,
        'Junio' : 664
    },
    byDia: {
        'Día 10': 353,
        'Día 22': 303,
        'Día 23': 290,
        'Día 20': 288,
        'Día 6' : 287
    } 
}
console.log('Top Five Values')
//https://maps.googleapis.com/maps/api/geocode/json?address=Costa Rica+San Jose+San Jose+Hospital&key=AIzaSyA8Wl_bLIyTd66ihMs096tEXzw3aQlIu3s