
from flask import Flask, request
from flask_cors import CORS, cross_origin
import prueba as p

app = Flask(__name__)
CORS(app, support_credentials=True)
@app.route("/prob")  # consider to use more elegant URL in your JS
@cross_origin()
def prob():
    anho = request.args.get('a') 
    fecha = request.args.get('f')
    canton = request.args.get('c')
    distrito = request.args.get('d')
    edad = request.args.get('e')
    genero = request.args.get('g')
    marca = request.args.get('m')
    hora =request.args.get('h')

    print(edad)
    return p.model(1,  marca,   anho,  fecha,     hora, edad, genero, canton, distrito) 

@app.route("/test")  # consider to use more elegant URL in your JS
@cross_origin()
def test():
     return p.model(  1, 'Toyota', 2018, '12/2/2019',  '03:00:00 - 05:59:59',   'Mayor de edad',  'HOMBRE',    'SAN JOSE', 'HOSPITAL')

if __name__ == "__main__":
    # here is starting of the development HTTP server
    app.run()

