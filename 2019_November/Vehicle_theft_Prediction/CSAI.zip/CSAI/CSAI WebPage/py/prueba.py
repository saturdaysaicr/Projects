import numpy as np
import pandas as pd
import pickle
import sklearn.ensemble
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
import matplotlib.pyplot as plt
import re
import random
from datetime import datetime
import seaborn as sns


def model(Id, Marca, AñoVehiculo, Fecha, Hora, Edad, Genero, Canton, Distrito, Nacionalidad='COSTA RICA', Auto=1):
	def add_datepart(df, fldname, drop=False):
		fld = df[fldname]
		if not np.issubdtype(fld.dtype, np.datetime64):
			df[fldname] = fld = pd.to_datetime(fld, 
                                     infer_datetime_format=True)
		targ_pre = re.sub('[Dd]ate$', '', fldname)
		for n in ('Year', 'Month', 'Week', 'Day', 'Dayofweek', 'Dayofyear', 'Is_month_end', 'Is_month_start', 'Is_quarter_end', 'Is_quarter_start', 'Is_year_end', 'Is_year_start'):
			df[targ_pre+n] = getattr(fld.dt,n.lower())
		df[targ_pre+'Elapsed'] = fld.astype(np.int64) // 10**9
		if drop: df.drop(fldname, axis=1, inplace=True)
 
            
	class MultiColumnLabelEncoder:
		def __init__(self,columns = None):
			self.columns = columns # array of column names to encode

		def fit(self,X,y=None):
			return self # not relevant here

		def transform(self,X):#'''Transforms columns of X specified in self.columns using LabelEncoder(). If no columns specified, transforms all columns in X.'''
			output = X.copy()
			if self.columns is not None:
				for col in self.columns:
					output[col] = LabelEncoder().fit_transform(output[col])
			else:
				for colname,col in output.iteritems():
					output[colname] = LabelEncoder().fit_transform(col)
			return output

		def fit_transform(self,X,y=None):
			return self.fit(X,y).transform(X)
        

	#hace data frame con variables de entrada
	data=[[Marca,AñoVehiculo,Fecha,Hora,Edad,Genero,Canton,Distrito,'COSTA RICA',1]] 
	df = pd.DataFrame(data, columns = ['Marca','AñoVehiculo','Fecha','Hora','Edad','Genero','Canton','Distrito', 'Nacionalidad', 'Auto']) 
	 
	df.AñoVehiculo = df.AñoVehiculo.astype(int)
	#Modificacion de variable Fecha  Octubre del 2018 hasta octubre del 2019, si se pudiera del 2017 aun mejor)
	df['Fecha'] =  pd.to_datetime(df['Fecha'], infer_datetime_format=True)
	add_datepart(df,'Fecha',drop=False)
	df=df.drop(['FechaElapsed'], axis=1)
	cols = ['FechaIs_month_end', 'FechaIs_month_start', 'FechaIs_quarter_end', 'FechaIs_quarter_start', 'FechaIs_year_end','FechaIs_year_start']
	df[cols] = df[cols].applymap(lambda x: 0 if x == False else 1)
	
	df['Fecha']= df['Fecha'].apply(lambda x: datetime.strftime(x, '%Y-%d-%m'))

	df['DiaCulturas'] = df['Fecha'].apply(lambda x: 1 if x == "2017-12-10" or x=="2018-12-10" or x=="2019-12-10" else 0)
	df['DiaSanJosé']= df['Fecha'].apply(lambda x: 1 if  x=="2018-19-03" or x=="2019-19-03" else 0)
	df['JueveViernesSanto']= df['Fecha'].apply(lambda x: 1 if x=="2019-18-04" or x=="2019-19-04" or x=="2018-29-03" or x=="2018-30-03" else 0)
	df['OtrosdiasSemanaSanta'] = df['Fecha'].apply(lambda x: 1 if x=="2019-13-04" or x=="2019-14-04" or x=="2019-15-04" or x=="2019-16-04" or x=="2019-17-04" or x=="2018-24-03" or x=="2018-25-03" or x=="2018-26-03" or x=="2018-27-03"  or x<="2018-28-03" else 0)
	df['BatalladeRivas']=df['Fecha'].apply(lambda x: 1 if  x=="2018-11-04" or x=="2019-11-04" else 0)
	df['DiaTrabajador']=df['Fecha'].apply(lambda x: 1 if  x=="2018-01-05" or x=="2019-01-05" else 0)
	df['AnexionGuanacaste']=df['Fecha'].apply(lambda x: 1 if  x=="2018-11-04" or x=="2019-11-04" else 0)
	df['DiaMadre']=df['Fecha'].apply(lambda x: 1 if  x=="2018-15-08" or x=="2019-15-08" else 0)
	df['Independencia']=df['Fecha'].apply(lambda x: 1 if  x=="2018-15-09" or x=="2019-15-09" else 0)
	df['Halloween']=df['Fecha'].apply(lambda x: 1 if x == "2017-31-10" or x=="2018-31-10" else 0)
	df['Navidad']=df['Fecha'].apply(lambda x: 1 if x=="2018-24-12" or x=="2018-25-12" or x=="2017-24-12" or x=="2017-25-12" else 0)
	df['AnoNuevo']=df['Fecha'].apply(lambda x: 1 if  x=="2018-01-01" or x=="2019-01-01" else 0)
	df['Walmart']=df['Fecha'].apply(lambda x: 1 if x=="2017-03-11" or x=="2018-02-11" or x=="2018-03-11" or x=="2018-04-11" else 0)
	
	df=df.drop(['Fecha'], axis=1)
	
		#Transform object data to category 
	df[df[['Hora','Edad','Genero', 'Nacionalidad','Canton','Distrito','Marca']].columns] = df[['Hora','Edad','Genero', 'Nacionalidad','Canton','Distrito', 'Marca']].apply(lambda x: x.astype('category'))
	
	#Categorical string to ordinal variables
	scale_mapper = {'Desconocido':0,
	                'Mayor de edad':1,
	                'Adulto Mayor':2}
	df['Edad'] = pd.Categorical(df.Edad, categories=['Desconocido','Mayor de edad','Adulto Mayor'], ordered=True)
	df['Edad'].cat.codes
	df['Edad'] = df['Edad'].replace(scale_mapper)
	df['Edad'].fillna(0, inplace=True)
	df.Edad = df.Edad.astype(int)
	
	scale_mapper = {'00:00:00 - 02:59:59':1,
	                '03:00:00 - 05:59:59':2,
	                '06:00:00 - 08:59:59':3,
	                '09:00:00 - 11:59:59':4,
	                '12:00:00 - 14:59:59':5,
	                '15:00:00 - 17:59:59':6,
	                '18:00:00 - 20:59:59':7,
	                '21:00:00 - 23:59:59':8}
	df['Hora'] = df['Hora'].replace(scale_mapper)
	
	cols = df.columns
	
	df=MultiColumnLabelEncoder(columns = ['Genero', 'Nacionalidad','Canton','Distrito', 'Marca', 'FechaIs_month_end', 'FechaIs_month_start','FechaIs_quarter_end', 'FechaIs_quarter_start', 'FechaIs_year_end','FechaIs_year_start',
	'DiaCulturas','DiaSanJosé','JueveViernesSanto','OtrosdiasSemanaSanta','BatalladeRivas','DiaTrabajador','AnexionGuanacaste','DiaMadre','Independencia','Halloween', 'Navidad', 'AnoNuevo','Walmart']).fit_transform(df)
	filename = 'finalized_modelCSAI.sav'
	loaded_model = pickle.load(open(filename, 'rb'))
	
	Id_test = Id
	
	UsuarioProb = loaded_model.predict_proba(df[cols])[::,1]
	return str(UsuarioProb[0])
	
		
	
